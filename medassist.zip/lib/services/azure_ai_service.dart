import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;

class AzureAiService {
  // --- IMPORTANT ---
  // Replace these with your actual Azure AI Vision endpoint and API Key.
  static const String _azureRegion = "eastus";
  static const String _azureEndpoint =
      "https://medassistvision.cognitiveservices.azure.com";
  static const String _apiKey =
      "61ExQX9sD2wC1FXXt3P8Us34WfsfRDuVwxbmdwwsS9Rnpm6WccJaJQQJ99BFACYeBjFXJ3w3AAAFACOGOAuX";

  // This function takes an image file, sends it to Azure for analysis,
  // and returns the descriptive text.
  static Future<String> analyzeImage(File imageFile) async {
    if (_azureEndpoint.contains("YOUR_AZURE") ||
        _apiKey.contains("YOUR_AZURE")) {
      // Provide a helpful error or a default simulated response if not configured.
      print("Azure AI Service is not configured. Returning simulated data.");
      await Future.delayed(const Duration(seconds: 2));
      return "Analisis gambar menunjukkan adanya ruam kemerahan dengan bintik-bintik kecil di area yang difoto. Tidak terlihat adanya luka terbuka atau nanah.";
    }

    try {
      // Read the image file as bytes.
      final url =
          '$_azureEndpoint/vision/v3.1/describe?language=en&maxCandidates=1';
      final uri = Uri.parse(url);
      final imageBytes = await imageFile.readAsBytes();

      final response = await http.post(
        uri,
        headers: {
          'Content-Type': 'application/octet-stream',
          'Ocp-Apim-Subscription-Key': _apiKey,
        },
        body: imageBytes,
      );

      if (response.statusCode == 200) {
        final Map<String, dynamic> jsonResponse =
            json.decode(utf8.decode(response.bodyBytes));

        if (jsonResponse != null && jsonResponse['description'] is Map) {
          final descriptionMap = jsonResponse['description'];
          if (descriptionMap['captions'] is List &&
              (descriptionMap['captions'] as List).isNotEmpty) {
            final captionsList = descriptionMap['captions'];
            final firstCaption = captionsList[0];
            if (firstCaption is Map && firstCaption['text'] is String) {
              return firstCaption['text'];
            }
          }
        }

        // Jika struktur tidak sesuai, lempar error yang lebih jelas.
        throw Exception(
            "Gagal mem-parsing 'captionResult' dari respons Azure.");
      } else {
        throw Exception(
            'Gagal menganalisis gambar. Status code: ${response.statusCode}, Body: ${response.body}');
      }
    } catch (e) {
      print("Error analyzing image: $e");
      throw Exception('Gagal menghubungi layanan analisis gambar.');
    }
  }
}

import 'package:cloud_firestore/cloud_firestore.dart';

class FirestoreService {
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  // Create a user document in Firestore
  Future<void> createUser(String uid, String fullName, String email) async {
    final userRef = _db.collection('users').doc(uid);
    final snapshot = await userRef.get();

    if (!snapshot.exists) {
      await userRef.set({
        'uid': uid,
        'fullName': fullName,
        'email': email,
        'createdAt': FieldValue.serverTimestamp(),
        'isDataComplete': false,
      });
    }
  }

  // Check if user's medical data is complete
  Future<bool> isMedicalDataComplete(String uid) async {
    try {
      DocumentSnapshot userDoc = await _db.collection('users').doc(uid).get();
      if (userDoc.exists) {
        return userDoc.get('isDataComplete') ?? false;
      }
      return false;
    } catch (e) {
      print(e);
      return false;
    }
  }

  // Update user medical data
  Future<void> updateMedicalData(String uid, Map<String, dynamic> data) async {
    try {
      data['isDataComplete'] = true;
      await _db.collection('users').doc(uid).set(data, SetOptions(merge: true));
    } catch (e) {
      rethrow;
    }
  }

  // --- UPDATED METHOD ---
  // Save a diagnosis result, now including the user's answers (prompt).
  Future<void> saveDiagnosisHistory(
      String uid, List<Map<String, dynamic>> results, String prompt) async {
    try {
      await _db
          .collection('users')
          .doc(uid)
          .collection('diagnosis_history')
          .add({
        'timestamp': FieldValue.serverTimestamp(),
        'results': results,
        'prompt': prompt, // Save the full prompt
      });
    } catch (e) {
      print('Error saving diagnosis history: $e');
      rethrow;
    }
  }
}

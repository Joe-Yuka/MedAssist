// lib/data/disease_data.dart

class DiseaseData {
  static final Map<String, Map<String, dynamic>> _diseaseDatabase = {
    'ISPA': {
      "title": "Infeksi Saluran Pernapasan Akut (ISPA)",
      "image":
          "https://primayahospital.b-cdn.net/wp-content/uploads/2024/03/B-6.jpg",
      "description":
          "ISPA adalah infeksi akut pada saluran pernapasan atas. Sering dianggap 'pilek' atau flu, ISPA umumnya sembuh sendiri dalam 3-14 hari bila disebabkan virus.",
      "treatment": [
        "Umum: Istirahat cukup, minum banyak air putih, konsumsi makanan bergizi.",
        "Simptomatik: Obat antipiretik/analgesik (paracetamol) untuk demam dan nyeri, obat dekongestan atau antihistamin untuk pilek.",
        "Kontrol: Pantau demam dan gejala. Jika batuk berdarah, sesak hebat, atau tidak membaik dalam >10 hari, cari pertolongan medis.",
      ],
    },
    'Pneumonia': {
      "title": "Pneumonia",
      "image":
          "https://iplungclinic.com/wp-content/uploads/2022/10/Picture-of-lung-with-Pneumonia.png",
      "description":
          "Pneumonia adalah infeksi pada paru-paru (saluran pernapasan bawah) yang menyebabkan radang dan pengisian cairan dalam alveoli (kantung udara paru).",
      "treatment": [
        "Antibiotik: Jika dicurigai bakteri, berikan antibiotik spektrum luas atau sesuai kultur.",
        "Supportif: Istirahat, hidrasi, antipiretik (paracetamol) untuk demam, analgesik untuk nyeri dada.",
        "Perawatan intensif: Jika sesak berat, bisa memerlukan oksigen atau ventilator.",
        "Viral: Jika disebabkan virus influenza/SARS-CoV-2, berikan antivirus (oseltamivir, remdesivir) jika tersedia.",
      ],
    },
    'Tuberkulosis': {
      "title": "Tuberkulosis (TBC)",
      "image":
          "https://asset.kompas.com/crops/y9_oR6zpKWsqobUSOpOm47kYe_4=/0x0:1000x667/1200x800/data/photo/2020/03/23/5e7837ada845b.jpg",
      "description":
          "Tuberkulosis adalah penyakit infeksi kronis utama pada paru-paru, disebabkan oleh bakteri Mycobacterium tuberculosis. Di Indonesia, TBC masih endemik dan termasuk penyebab kematian tinggi.",
      "treatment": [
        "Obat anti-TBC: Kombinasi 4 obat (isoniazid, rifampisin, pirazinamid, etambutol) minimal 6 bulan (skema OAT) sesuai program DOTS.",
        "Dukungan: Gizi adekuat, rehat, minum yang cukup, dan disiplin obat.",
        "Pencegahan: Skrining kontak TBC, vaksinasi BCG pada bayi, dan menerapkan perilaku hidup bersih.",
      ],
    },
    'DBD': {
      "title": "Demam Berdarah Dengue (DBD)",
      "image":
          "https://rspkuboyolali.co.id/wp-content/uploads/2019/03/gejala-demam-berdarah.jpg",
      "description":
          "Demam Dengue adalah infeksi virus dengue (Flavivirus) yang ditularkan oleh nyamuk Aedes aegypti. Jika berat disebut Demam Berdarah Dengue (DBD).",
      "treatment": [
        "Supportif: Cairan oral rehidrasi intensif, paracetamol untuk demam. Hindari obat pengencer darah/NSAID.",
        "RS/intravenous: Jika tanda peringatan (DSS), berikan infus Ringer laktat/dextran, rawat di RS dekat.",
        "Pencegahan: Pemberantasan sarang nyamuk (3M Plus), penggunaan kelambu dan losion anti-nyamuk."
      ],
    },
    'Infeksi Virus Umum': {
      "title": "Infeksi Virus Non-Spesifik",
      "image": "https://i.ibb.co/3kR0Vsf/ispa.jpg",
      "description":
          "Istilah ini digunakan untuk penyakit yang disebabkan oleh virus dengan gejala umum seperti demam, batuk, pilek, dan sakit kepala. Seringkali tidak memerlukan pengobatan spesifik dan dapat sembuh dengan istirahat.",
      "treatment": [
        "Istirahat yang cukup.",
        "Minum banyak cairan seperti air putih, jus, atau sup hangat untuk mencegah dehidrasi.",
        "Gunakan obat pereda nyeri yang dijual bebas seperti paracetamol atau ibuprofen untuk meredakan demam dan nyeri.",
        "Gunakan pelembap udara (humidifier) untuk mengurangi hidung tersumbat dan sakit tenggorokan."
      ],
    },
    'Influenza': {
      "title": "Influenza (Flu)",
      "image":
          "https://d1vbn70lmn1nqe.cloudfront.net/prod/wp-content/uploads/2021/06/29071336/flu.jpeg",
      "description":
          "Influenza adalah penyakit pernapasan menular yang disebabkan oleh virus influenza. Gejalanya bisa ringan hingga berat dan terkadang dapat menyebabkan kematian.",
      "treatment": [
        "Obat antivirus seperti oseltamivir (Tamiflu), zanamivir (Relenza), peramivir (Rapivab), atau baloxavir marboxil (Xofluza).",
        "Perbanyak istirahat dan minum cairan.",
        "Obat pereda nyeri dan demam yang dijual bebas.",
        "Pencegahan terbaik adalah vaksinasi flu tahunan."
      ],
    },
    'COVID-19': {
      "title": "COVID-19",
      "image": "https://unair.ac.id/wp-content/uploads/2024/01/covid-19.jpg",
      "description":
          "COVID-19 adalah penyakit menular yang disebabkan oleh virus SARS-CoV-2. Gejalanya sangat bervariasi, dari ringan seperti flu hingga penyakit pernapasan yang parah.",
      "treatment": [
        "Untuk kasus ringan: istirahat di rumah, isolasi, dan minum obat pereda gejala.",
        "Untuk kasus sedang hingga berat: perawatan di rumah sakit mungkin diperlukan, termasuk terapi oksigen, obat antivirus seperti Remdesivir, atau obat anti-inflamasi seperti deksametason.",
        "Vaksinasi adalah cara paling efektif untuk mencegah penyakit parah."
      ],
    },
    'Hepatitis B': {
      "title": "Hepatitis B",
      "image":
          "https://rspp.co.id/uploads/img_post/img_0804202517440818492X58S.jpg",
      "description":
          "Hepatitis B adalah peradangan hati akibat infeksi virus HBV. Dapat bersifat akut atau kronis dan menular melalui darah serta cairan tubuh.",
      "treatment": [
        "Akut: Istirahat, hindari alkohol, diet ringan, dan pengobatan simptomatik. Biasanya sembuh sendiri.",
        "Kronis: Terapi dengan antivirus oral (tenofovir, entecavir) untuk menekan replikasi virus dan kontrol rutin fungsi hati.",
        "Pencegahan: Imunisasi lengkap, hindari kontak darah, dan cegah penularan perinatal."
      ],
    },
    'Hepatitis C': {
      "title": "Hepatitis C",
      "image":
          "https://rspp.co.id/uploads/img_post/img_0804202517440818492X58S.jpg",
      "description":
          "Hepatitis C adalah infeksi hati oleh virus HCV. Lebih banyak kasus menjadi kronis dibanding Hepatitis B dan sering tidak terdiagnosis sampai bertahun-tahun.",
      "treatment": [
        "Antivirus Langsung (DAA): Sofosbuvir, ledipasvir, daclatasvir, dll. Tingkat kesembuhan sangat tinggi (>95%).",
        "Perawatan Pendukung: Jaga fungsi hati dengan menghindari alkohol dan obat-obatan yang toksik bagi hati.",
        "Pencegahan: Tidak ada vaksin. Hindari transfusi darah tanpa uji HCV dan penggunaan jarum suntik yang tidak steril."
      ],
    },
    'Malaria': {
      "title": "Malaria",
      "image":
          "https://www.embl.org/news/wp-content/uploads/2024/03/2024-Malaria-PLOS-Biology-1000x600-1.jpeg",
      "description":
          "Malaria adalah penyakit infeksi parasit Plasmodium yang ditularkan oleh gigitan nyamuk Anopheles betina. Gejala muncul secara siklik sesuai siklus perkembangan parasit di dalam darah.",
      "treatment": [
        "Obat Antimalaria: Kombinasi artemisinin (ACT) untuk P. falciparum; klorokuin untuk P. vivax nonresisten.",
        "Dukungan: Rawat di RS jika demam >39\u2103 atau jika ada gejala berat.",
        "Pencegahan: Tidur menggunakan kelambu berinsektisida, minum obat pencegahan (profilaksis) bagi pelancong, dan basmi sarang nyamuk."
      ],
    },
    'Tifus': {
      "title": "Demam Tifoid (Tifus)",
      "image":
          "https://static.honestdocs.id/system/conditions/images/000/001/429/original/Tifus_%28Typhus%29_.jpg",
      "description":
          "Demam tifoid adalah infeksi sistemik yang disebabkan oleh bakteri Salmonella typhi. Penyakit ini masih umum di daerah dengan sanitasi yang buruk.",
      "treatment": [
        "Antibiotik: Penicillin, chloramphenicol, atau antibiotik generasi baru (azitromisin, ceftriaxon) sesuai sensitivitas bakteri.",
        "Supportif: Obat penurun demam, dan pemberian cairan oral/IV bila terjadi dehidrasi.",
        "Pencegahan: Vaksinasi, sanitasi makanan dan minuman yang baik, serta cuci tangan secara teratur."
      ],
    },
    'Diare Akut': {
      "title": "Diare Akut",
      "image":
          "https://d1bpj0tv6vfxyp.cloudfront.net/jangansalahinibedanyadiarekronisdengandiareakuthalodoc.jpg",
      "description":
          "Diare akut adalah peningkatan frekuensi buang air besar (3 kali per hari atau lebih) dengan konsistensi cair. Disebabkan oleh infeksi virus, bakteri, atau parasit.",
      "treatment": [
        "Rehidrasi Segera: Oralit (rehidrasi oral) sesegera mungkin. Pada dehidrasi sedang-berat, mungkin diperlukan cairan infus.",
        "Diet: Lanjutkan ASI/makanan biasa, namun hindari makanan berat.",
        "Antibiotik/Antiparasit: Diberikan hanya bila disebabkan oleh bakteri atau parasit tertentu seperti Shigella, Giardia, atau Cholera."
      ],
    },
    'Cacingan': {
      "title": "Infeksi Cacing (Cacingan)",
      "image":
          "https://sejawat.s3.ap-southeast-1.amazonaws.com/sejawat/file/cdc954e5a946b29b099525bcc675379f/612600e5bd799.jpg",
      "description":
          "Cacingan adalah infeksi usus yang disebabkan oleh cacing parasit seperti cacing gelang, cacing tambang, atau cacing kremi. Sering terjadi pada anak-anak di area tropis.",
      "treatment": [
        "Obat Cacing: Albendazole atau mebendazole.",
        "Dukungan Gizi: Obat penambah darah jika terjadi anemia.",
        "Pencegahan: Sanitasi lingkungan yang baik, cuci tangan sebelum makan, dan memasak makanan hingga matang."
      ],
    },
    'Leptospirosis': {
      "title": "Leptospirosis",
      "image":
          "https://static.promediateknologi.id/crop/0x0:0x0/0x0/webp/photo/p2/66/2023/11/05/snapedit_1699159763841-3953049044.png",
      "description":
          "Leptospirosis adalah penyakit zoonosis tropis yang disebabkan oleh bakteri Leptospira. Bakteri ini menular ke manusia melalui kontak dengan urine hewan yang terinfeksi.",
      "treatment": [
        "Antibiotik: Doksisiklin atau penisilin (IV pada kasus berat) segera setelah dicurigai untuk mencegah komplikasi.",
        "Supportif: Rehidrasi IV dan kontrol elektrolit.",
        "Pencegahan: Hindari kontak dengan air kotor yang bisa terkontaminasi, dan gunakan perlindungan (sarung tangan, sepatu boots) di area berisiko."
      ],
    },
    'Filariasis (Kaki Gajah)': {
      "title": "Filariasis (Kaki Gajah)",
      "image":
          "https://www.kapuashulukab.go.id/home/public/assets/images/posts/md_47Penyakit%20Kaki%20Gajah.jpg",
      "treatment": [
        "Pemberantasan cacing: Diethylcarbamazine (DEC) dosis tunggal (lemak hati dosis berat) untuk membunuh cacing dewasa dan larva. Atau kombinasi albendazole+ivermectin di program filariasis massal.",
        "Pengobatan sekunder: Uji mikrobaasi Wb (DEC harian 12 hari) untuk kasus pribadi. ",
        "Terapi milsa/pembedahan: Pada hydrocele (pembengkakan skrotum) atau jaringan parut ekstrem, diperlukan operasi."
      ],
    },
    'Rabies': {
      "title": "Rabies",
      "image":
          "https://static.promediateknologi.id/crop/0x0:0x0/0x0/webp/photo/p2/66/2023/11/05/snapedit_1699159763841-3953049044.png",
      "description":
          "Rabies adalah infeksi virus Lyssavirus mematikan pada sistem saraf pusat, ditandai dengan ensefalitis progresif. Biasanya disebabkan gigitan atau cakaran hewan mamalia terinfeksi (anjing, kucing, kera, kelelawar).",
      "treatment": [
        "Sesaat setelah gigitan: Cuci luka dengan sabun/deterjen + air mengalir, pemberian antirabies immunoglobulin (HRIG) di tempat luka dan sekitarnya, ditambah vaksinasi rabies tetes (dosis 4–5 kali dalam 1 bulan)",
        "Setelah gejala muncul: Belum ada obat yang efektif. Rawat suportif di ICU (menekan kejang, ceftriaxone untuk rawat sekunder, ventilator jika paralisis napas). Prognosis sangat buruk; fatalitas 100%. Paliatif.",
      ],
    },
    'Difteri': {
      "title": "Difteri",
      "image":
          "https://img-cdn.medkomtek.com/pDlDvE91-vb0oPb4Off_gkEHt4Q=/510x395/smart/filters:quality(100):format(webp)/article/eOixL28nncsO5X5mCDfoT/original/013507500_1555913463-_X_-Komplikasi-Difteri-yang-Perlu-Anda-Tahu-Difteri-by-Nigeriagalleria-com.jpg",
      "description":
          "Difteri adalah infeksi akut karena Corynebacterium diphtheriae yang terutama menyerang selaput lendir hidung dan tenggorokan.",
      "treatment": [
        "Antitoksin: Vaksin difteri (antitoksin equine) segera injeksi intramuskular untuk menetralkan toksin (tidak berguna setelah terikat ke sel).",
        "Antibiotik: Eritromisin atau penisilin untuk membunuh bakteri, mencegah penyebaran lebih lanjut.",
        "Supportif: Dekompresi jalan napas (intubasi/trakeostomi) jika pseudomembran obstruksi; monitor jantung (EKG) untuk gejala toksin.",
        "Isolasi: Pasien isolasi respiratorik minimal 48 jam selama antibiotik.",
      ],
    },
    'Campak (Measles)': {
      "title": "Campak (Measles)",
      "image":
          "https://res.cloudinary.com/dk0z4ums3/image/upload/v1748083420/attached_image/campak-pada-orang-dewasa-apakah-menular-ini-jawabannya.jpg",
      "description":
          "Campak adalah infeksi saluran pernapasan akut oleh virus Morbilli (Paramyxovirus). Sangat menular melalui droplet.",
      "treatment": [
        "Supportif: Perbaiki nutrisi (Vit A suplemen terbukti mengurangi komplikasi), cairan cukup.",
        "Demam & nyeri: Obat antipiretik (paracetamol).",
        "Komplikasi: Antibiotik jika pneumonia/superinfeksi tenggorokan terjadi.",
        "Tidak ada antivirus spesifik untuk measles.",
      ],
    },
    'Cacar Air (Varisela)': {
      "title": "Cacar Air (Varisela)",
      "image":
          "https://res.cloudinary.com/dk0z4ums3/image/upload/v1748083420/attached_image/campak-pada-orang-dewasa-apakah-menular-ini-jawabannya.jpg",
      "description":
          "Cacar air (varicella) adalah infeksi virus Varicella zoster yang menyebabkan ruam lepuh gatal di seluruh tubuh.",
      "treatment": [
        "Supportif: Kompres dingin/air hangat untuk gatal, mandi air dingin, pakaian longgar.",
        "Antipiretik/analgesik: Paracetamol untuk demam. Hindari aspirin (risiko Reye).",
        "Antihistamin/topikal: Salep kalamin untuk gatal.",
        "Antivirus: Valaciclovir/acyclovir terutama pada dewasa, penderita berat, atau imunokompromais.",
        "Isolasi: Sampai semua lepuh mengering untuk menghindari penularan.",
      ],
    },
    'Hipertensi': {
      "title": "Hipertensi",
      "image":
          "https://fahum.umsu.ac.id/blog/wp-content/uploads/2024/06/gejala-dan-cara-mengatasi-penyakit-hipertensi.jpg",
      "description":
          "Hipertensi (tekanan darah tinggi) adalah kondisi kronis di mana tekanan darah sistolik 140 mmHg atau diastolik 90 mmHg secara konsisten.",
      "treatment": [
        "Gaya Hidup: Diet rendah garam, kurangi berat badan, rutin olahraga, hindari alkohol/rokok, kurangi stres.",
        "Medikamentosa: Diuretik, ACE inhibitors, ARB, kalsium antagonis, beta-blocker sesuai kebutuhan. Kombinasi sering diperlukan untuk target tekanan.",
        "Pantau darah sendiri di rumah bila perlu.",
      ],
    },
    'Diabetes Mellitus Tipe 2': {
      "title": "Diabetes Mellitus Tipe 2",
      "image": "https://ai-care.id/photos/63984bf52477e.jpg",
      "description":
          "Diabetes Mellitus tipe 2 adalah penyakit metabolik kronis dengan kadar gula darah tinggi karena resistensi insulin atau sekresi insulin tidak cukup.",
      "treatment": [
        "Diet dan Olahraga: Kontrol berat badan, diet rendah karbohidrat, olah raga rutin",
        "Obat oral: Metformin lini pertama, bisa ditambahkan sulfonilurea, DPP-4 inhibitor, SGLT2 inhibitor, dll",
        "Injeksi: Jika perlu (insulin), terutama pada dekompensasi.",
        "Kontrol komplikasi: Periksa mata, ginjal, kardiovaskular secara rutin.",
      ],
    },
    'Penyakit Jantung Koroner': {
      "title": "Penyakit Jantung Koroner",
      "image":
          "https://upload.wikimedia.org/wikipedia/commons/thumb/d/d1/Blausen_0257_CoronaryArtery_Plaque.png/800px-Blausen_0257_CoronaryArtery_Plaque.png",
      "description":
          "Penyakit Jantung Koroner (PJK) adalah kondisi sumbatan pada arteri koroner (yang mensuplai darah ke otot jantung) akibat plak aterosklerosis.",
      "treatment": [
        "Obat: Nitrat (isosorbid) untuk nyeri dada, aspirin/antiplatelet, statin (turunkan kolesterol), beta-blocker, ACE inhibitor.",
        "Intervensi: Balon/stent koroner pada kasus stenosis berat, atau operasi bypass arteri koroner (CABG).",
        "Gaya hidup: Hentikan merokok, diet rendah lemak, kontrol tekanan dan gula darah.",
      ],
    },
    'Stroke': {
      "title": "Stroke",
      "image":
          "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR6zPDrAOtEBqSxMIgHXlkIuJ0pxXzS7RH56A&s",
      "description":
          "Stroke adalah gangguan fungsi otak akibat suplai darah terganggu (iskemik) atau pembuluh pecah.",
      "treatment": [
        "Stroke Iskemik akut: TPA (tissue plasminogen activator) IV dalam 4,5 jam jika memenuhi kriteria. Aspirin/antiplatelet segera.",
        "Stroke Hemoragik: Kontrol tekanan darah ketat, pembedahan (kliping atau hematoma evacuation) jika perlu.",
        "Rehabilitasi: Fisioterapi, okupasi, terapi bicara segera setelah stabil.",
      ],
    },
    'Gagal Ginjal': {
      "title": "Gagal Ginjal",
      "image": "https://dinkes.jakarta.go.id/assets/upload/image/ginjal.jpg",
      "description":
          "Asma adalah penyakit inflamasi kronik saluran pernapasan yang menyebabkan penyempitan reversibel dan mengi (napas berbunyi siulan)",
      "treatment": [
        "Pencegahan pemicu: Hindari rokok, alergen, polusi. Vaksinasi influenza/ pneumonia untuk mencegah eksaserbasi.",
        "Obat teratur: Inhaler kortikosteroid (pencegah) untuk peradangan. Inhaler bronkodilator cepat (beta-agonis: salbutamol) bila kambuh.",
        "Obat tambahan: Leukotriene antagonis, teofilin, antikolinergik (ipratropium).",
        "Edukasi: Teknik inhalasi benar, rencana tindakan serangan asma darurat.",
        "Perawatan gizi/olahraga: Menjaga kebugaran paru.",
      ],
    },
    'Osteoartritis': {
      "title": "Osteoartritis",
      "image":
          "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT6jt7HNQ_CvWSWUNcN1gWGT0G0UOluTr24KA&s",
      "description":
          "Osteoartritis (OA) adalah penyakit sendi degeneratif akibat kerusakan tulang rawan sendi. Paling sering terjadi pada lutut, pinggul, tangan, dan tulang belakang.",
      "treatment": [
        "Modifikasi gaya hidup: Turunkan berat badan untuk lutut/pinggul, lakukan fisioterapi dan latihan untuk memperkuat otot sekitarnya. ",
        "Obat: Paracetamol atau NSAID untuk nyeri; krim topikal atau patch analgesik di area sendi.",
        "Suplemen: Glukosamin/Kondroitin (efektivitas variabel).",
        "EPembedahan: Jika parah, dapat dipertimbangkan arthroplasty (penggantian sendi, misal lutut/ pinggul).",
        "Terapi fisik: Hot pack atau gentle stretching.",
      ],
    },
    'Penyakit Paru Obstruktif Kronis (PPOK)': {
      "title": "Penyakit Paru Obstruktif Kronis (PPOK)",
      "image":
          "https://rsum.bandaacehkota.go.id/wp-content/uploads/2024/12/PPOK.jpg",
      "description":
          "PPOK adalah kondisi inflamasi paru jangka panjang yang menyebabkan obstruksi saluran napas ireversibel. Umumnya terdiri dari bronkitis kronis dan emfisema.",
      "treatment": [
        "Berhenti merokok: Langkah terpenting.",
        "Medikasi: Inhaler bronchodilator (beta-agonis, antikolinergik), kortikosteroid inhalasi pada eksaserbasi berulang.",
        "Terapi oksigen: Jika hipoksemia berat.",
        "Vaksinasi: Influenza dan pneumokokus untuk mencegah infeksi paru komorbid.",
        "Rehabilitasi paru: Latihan pernapasan, fisik.",
        "Pengawasan: Pencitraan rutin untuk deteksi kanker paru (risiko tinggi).",
      ],
    }
  };

  // --- LOGIC UPDATED HERE ---
  static Map<String, dynamic> getDiseaseData(String nameFromAI) {
    // 1. Try for a direct, exact match first.
    if (_diseaseDatabase.containsKey(nameFromAI)) {
      return _diseaseDatabase[nameFromAI]!;
    }

    // 2. If no direct match, try a partial match (case-insensitive).
    final nameFromAILower = nameFromAI.toLowerCase();
    for (var key in _diseaseDatabase.keys) {
      if (nameFromAILower.contains(key.toLowerCase())) {
        return _diseaseDatabase[key]!;
      }
    }

    // 3. If still no match, return a default "not found" object.
    return {
      "title": nameFromAI, // Show the name we got from the AI
      "image": null,
      "description":
          "Informasi detail untuk penyakit ini tidak tersedia dalam panduan medis saat ini.",
      "treatment": [
        "Segera konsultasikan dengan dokter untuk penanganan lebih lanjut."
      ]
    };
  }

  static List<String> getAllDiseaseNames() {
    return _diseaseDatabase.keys.toList();
  }
}

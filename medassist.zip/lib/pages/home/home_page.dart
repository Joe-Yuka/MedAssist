import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:medassist/pages/auth/login_page.dart';
import 'package:medassist/pages/data_kesehatan/data_kesehatan_page.dart';
import 'package:medassist/pages/diagnosis/symptom_selection_page.dart';
import 'package:medassist/pages/panduan_medis/panduan_medis_page.dart';
import 'package:medassist/pages/riwayat/riwayat_diagnosa_page.dart';
import 'package:url_launcher/url_launcher.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  String _userName = 'Yuka'; // Default name

  @override
  void initState() {
    super.initState();
    _fetchUserName();
  }

  Future<void> _fetchUserName() async {
    final user = _auth.currentUser;
    if (user != null) {
      final doc = await FirebaseFirestore.instance
          .collection('users')
          .doc(user.uid)
          .get();
      if (doc.exists && doc.data()!.containsKey('fullName')) {
        setState(() {
          _userName = doc.data()!['fullName'].toString().split(' ').first;
        });
      }
    }
  }

  Future<void> _logout() async {
    bool? confirmed = await showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Konfirmasi'),
        content: const Text('Apakah Anda yakin ingin keluar?'),
        actions: [
          TextButton(
              onPressed: () => Navigator.of(context).pop(false),
              child: const Text('Tidak')),
          TextButton(
              onPressed: () => Navigator.of(context).pop(true),
              child: const Text('Ya')),
        ],
      ),
    );

    if (confirmed == true) {
      await _auth.signOut();
      if (mounted) {
        Navigator.of(context).pushAndRemoveUntil(
          MaterialPageRoute(builder: (context) => const LoginPage()),
          (Route<dynamic> route) => false,
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // --- PERUBAHAN UTAMA ADA DI SINI ---
      appBar: AppBar(
        backgroundColor: const Color.fromRGBO(255, 171, 64, 1),
        elevation: 0,
        automaticallyImplyLeading: false, // Menghilangkan tombol kembali
        title: Row(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Image.asset(
              'assets/images/logo-pinggir-white.png', // Pastikan path ini benar
              fit: BoxFit.contain,
              height: 140,
            ),
          ],
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: Colors.grey.shade200,
                borderRadius: BorderRadius.circular(20),
              ),
              child: Row(
                children: [
                  const CircleAvatar(
                    radius: 30,
                    backgroundColor: Colors.grey,
                    child: Icon(Icons.person, size: 40, color: Colors.white),
                  ),
                  const SizedBox(width: 15),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Selamat Malam, $_userName!',
                            style: const TextStyle(
                                fontSize: 18, fontWeight: FontWeight.bold)),
                        Text('MedAssist siap membantu',
                            style: TextStyle(color: Colors.grey.shade700)),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 30),
            const Center(
                child: Text('MENU',
                    style:
                        TextStyle(fontSize: 22, fontWeight: FontWeight.bold))),
            const SizedBox(height: 20),
            _buildMenuButton(
              icon: Icons.person_search,
              title: 'Diagnosa Pasien',
              subtitle: 'Membantu Diagnosa Penyakit',
              onTap: () {
                Navigator.of(context).push(MaterialPageRoute(
                  builder: (context) => const SymptomSelectionPage(),
                ));
              },
            ),
            _buildMenuButton(
              icon: Icons.medical_services,
              title: 'Panduan Medis',
              subtitle: 'Lihat daftar penyakit dan penanganannya',
              onTap: () {
                Navigator.of(context).push(MaterialPageRoute(
                  builder: (context) => const PanduanMedisPage(),
                ));
              },
            ),
            _buildMenuButton(
              icon: Icons.history,
              title: 'Riwayat Diagnosa',
              subtitle: 'Membantu Diagnosa Penyakit',
              onTap: () {
                Navigator.of(context).push(MaterialPageRoute(
                  builder: (context) => const RiwayatDiagnosaPage(),
                ));
              },
            ),
            _buildMenuButton(
              icon: Icons.assignment_ind,
              title: 'Data Kesehatan',
              subtitle: 'Kumpulan Data Kesehatan Dalam Aplikasi',
              onTap: () => Navigator.of(context).push(MaterialPageRoute(
                builder: (context) =>
                    const DataKesehatanPage(isFirstTime: false),
              )),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: _logout,
              child: const Text('Log Out'),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.red,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(vertical: 16),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(30)),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildMenuButton(
      {required IconData icon,
      required String title,
      required String subtitle,
      required VoidCallback onTap}) {
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 8.0),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      color: Colors.orangeAccent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(20),
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Row(
            children: [
              Icon(icon, size: 40, color: Colors.white),
              const SizedBox(width: 15),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(title,
                        style: const TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                            color: Colors.white)),
                    Text(subtitle,
                        style: TextStyle(color: Colors.white.withOpacity(0.9))),
                  ],
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}

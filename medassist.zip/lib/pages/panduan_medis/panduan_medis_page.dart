// lib/pages/panduan_medis/panduan_medis_page.dart

import 'package:flutter/material.dart';
import 'package:medassist/data/disease_data.dart';
import 'package:medassist/pages/diagnosis/disease_detail_page.dart';

class PanduanMedisPage extends StatelessWidget {
  const PanduanMedisPage({super.key});

  @override
  Widget build(BuildContext context) {
    final diseaseNames = DiseaseData.getAllDiseaseNames();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Panduan Medis'),
        backgroundColor: Colors.orangeAccent,
      ),
      body: ListView.builder(
        itemCount: diseaseNames.length,
        itemBuilder: (context, index) {
          final diseaseName = diseaseNames[index];
          return Card(
            margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: ListTile(
              title: Text(diseaseName,
                  style: const TextStyle(fontWeight: FontWeight.bold)),
              trailing: const Icon(Icons.arrow_forward_ios, color: Colors.grey),
              onTap: () {
                Navigator.of(context).push(MaterialPageRoute(
                  builder: (context) =>
                      DiseaseDetailPage(diseaseName: diseaseName),
                ));
              },
            ),
          );
        },
      ),
    );
  }
}

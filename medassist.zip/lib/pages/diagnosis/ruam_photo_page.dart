import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:medassist/models/diagnosis_question.dart';
import 'package:medassist/pages/diagnosis/question_page.dart';
import 'package:medassist/services/azure_ai_service.dart';

class RuamPhotoPage extends StatefulWidget {
  final String initialPrompt;
  final List<DiagnosisQuestion> questions;

  const RuamPhotoPage({
    super.key,
    required this.initialPrompt,
    required this.questions,
  });

  @override
  _RuamPhotoPageState createState() => _RuamPhotoPageState();
}

class _RuamPhotoPageState extends State<RuamPhotoPage> {
  File? _imageFile;
  bool _isAnalyzing = false;
  String? _analysisResult;

  Future<void> _pickImage() async {
    final picker = ImagePicker();
    final pickedFile =
        await picker.pickImage(source: ImageSource.camera, imageQuality: 50);

    if (pickedFile != null) {
      setState(() {
        _imageFile = File(pickedFile.path);
        _isAnalyzing = true;
        _analysisResult = null; // Clear previous result
      });

      // Analyze the image
      final result = await AzureAiService.analyzeImage(_imageFile!);
      setState(() {
        _analysisResult = result;
        _isAnalyzing = false;
      });
    }
  }

  void _continueToQuestions() {
    if (_analysisResult == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
            content: Text('Mohon ambil dan analisis foto terlebih dahulu.')),
      );
      return;
    }

    final promptWithImageAnalysis =
        '${widget.initialPrompt}\nHasil analisis gambar ruam: $_analysisResult. ';

    Navigator.of(context).pushReplacement(MaterialPageRoute(
      builder: (context) => QuestionPage(
        questions: widget.questions,
        currentQuestionIndex: 0,
        currentPrompt: promptWithImageAnalysis,
      ),
    ));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Analisis Foto Ruam'),
        backgroundColor: Colors.orangeAccent,
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const Text(
                'Silakan ambil foto ruam Anda untuk dianalisis.',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 20),
              Container(
                height: 250,
                width: 250,
                decoration: BoxDecoration(
                  border: Border.all(color: Colors.grey),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: _imageFile != null
                    ? Image.file(_imageFile!, fit: BoxFit.cover)
                    : const Center(
                        child: Icon(Icons.image, size: 80, color: Colors.grey)),
              ),
              const SizedBox(height: 20),
              ElevatedButton.icon(
                onPressed: _pickImage,
                icon: const Icon(Icons.camera_alt),
                label: const Text('Ambil Foto Ruam'),
                style: ElevatedButton.styleFrom(
                  minimumSize: const Size(0, 50),
                ),
              ),
              const SizedBox(height: 20),
              if (_isAnalyzing)
                const Center(
                    child: Column(
                  children: [
                    CircularProgressIndicator(),
                    SizedBox(height: 10),
                    Text("Menganalisis...")
                  ],
                )),
              if (_analysisResult != null)
                Card(
                  color: Colors.green.shade50,
                  child: Padding(
                    padding: const EdgeInsets.all(12.0),
                    child: Text('Hasil Analisis: $_analysisResult'),
                  ),
                ),
              const Spacer(),
              ElevatedButton(
                onPressed:
                    _analysisResult != null ? _continueToQuestions : null,
                child: const Text('Lanjutkan'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.green,
                  foregroundColor: Colors.white,
                  minimumSize: const Size(double.infinity, 50),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(30),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

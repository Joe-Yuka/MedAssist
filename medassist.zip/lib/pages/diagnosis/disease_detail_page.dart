// lib/pages/diagnosis/disease_detail_page.dart

import 'package:flutter/material.dart';
import 'package:medassist/data/disease_data.dart'; // Import the new data file

class DiseaseDetailPage extends StatelessWidget {
  final String diseaseName;
  const DiseaseDetailPage({super.key, required this.diseaseName});

  @override
  Widget build(BuildContext context) {
    // Get the data from the centralized source
    final data = DiseaseData.getDiseaseData(diseaseName);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Penanganan'),
        backgroundColor: Colors.orangeAccent,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 15),
              decoration: BoxDecoration(
                color: Colors.orange.shade300,
                borderRadius: BorderRadius.circular(30),
              ),
              child: Text(
                data['title'],
                style: const TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                    color: Colors.white),
              ),
            ),
            const SizedBox(height: 20),
            Card(
              elevation: 4,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(15)),
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    if (data['image'] != null)
                      ClipRRect(
                        borderRadius: BorderRadius.circular(10),
                        child: Image.network(data['image'],
                            fit: BoxFit.cover,
                            width: double.infinity,
                            height: 180),
                      ),
                    const SizedBox(height: 15),
                    Text(data['description'],
                        style: const TextStyle(fontSize: 16)),
                    const SizedBox(height: 20),
                    const Text('Penanganan & Pengobatan',
                        style: TextStyle(
                            fontSize: 18, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 10),
                    ...List<Widget>.from((data['treatment'] as List<String>)
                        .map((item) => Padding(
                              padding: const EdgeInsets.only(bottom: 8.0),
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  const Text("- ",
                                      style: TextStyle(
                                          fontSize: 16,
                                          fontWeight: FontWeight.bold)),
                                  Expanded(
                                      child: Text(item,
                                          style:
                                              const TextStyle(fontSize: 16))),
                                ],
                              ),
                            ))),
                  ],
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
}

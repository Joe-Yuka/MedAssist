import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:medassist/models/diagnosis_question.dart';
import 'package:medassist/pages/diagnosis/question_page.dart';
import 'package:medassist/pages/diagnosis/ruam_photo_page.dart';

class SymptomSelectionPage extends StatefulWidget {
  const SymptomSelectionPage({super.key});

  @override
  _SymptomSelectionPageState createState() => _SymptomSelectionPageState();
}

class _SymptomSelectionPageState extends State<SymptomSelectionPage> {
  // This map now holds all questions, keyed by the main symptom.
  final Map<String, List<DiagnosisQuestion>> _symptomQuestions = {
    'Demam': [
      // --- NEW THERMOMETER QUESTION ---
      DiagnosisQuestion(
          questionId: 'has_thermometer', // Special ID for logic handling
          questionText: 'Apakah kamu punya termometer?',
          // This prompt is used if the user answers "No"
          promptText: 'tidak mengukur suhu karena tidak ada termometer'),
      // --- TEMPERATURE QUESTION IS NOW TEXT INPUT ---
      DiagnosisQuestion(
          questionId: 'ask_temperature',
          questionText: 'Berapa suhu tubuh Anda dalam \u2103?',
          isTextInput: true,
          // This is the base for the prompt, the value will be appended
          promptText: 'suhu tubuh'),
      DiagnosisQuestion(
          questionText: 'Apakah demam muncul tiba-tiba?',
          promptText: 'demam muncul tiba-tiba'),
      DiagnosisQuestion(
          questionText: 'Apakah demam disertai menggigil?',
          promptText: 'demam disertai menggigil'),
      DiagnosisQuestion(
          questionText: 'Apakah Anda merasa lemas atau lesu saat demam?',
          promptText: 'merasa lemas atau lesu saat demam'),
      DiagnosisQuestion(
          questionText: 'Apakah demam muncul terutama pada malam hari?',
          promptText: 'demam muncul terutama pada malam hari'),
      DiagnosisQuestion(
          questionText: 'Apakah demam disertai berkeringat berlebihan?',
          promptText: 'demam disertai berkeringat berlebihan'),
      DiagnosisQuestion(
          questionText: 'Apakah demam terjadi bersamaan dengan batuk?',
          promptText: 'demam terjadi bersamaan dengan batuk'),
      DiagnosisQuestion(
          questionText:
              'Apakah Anda mengalami penurunan nafsu makan saat demam?',
          promptText: 'mengalami penurunan nafsu makan saat demam'),
      DiagnosisQuestion(
          questionText: 'Apakah Anda baru saja bepergian ke daerah endemis?',
          promptText: 'baru saja bepergian ke daerah endemis'),
      DiagnosisQuestion(
          questionText: 'Apakah demam sudah berlangsung lebih dari 3 hari?',
          promptText: 'demam sudah berlangsung lebih dari 3 hari'),
    ],
    'Batuk': [
      DiagnosisQuestion(
          questionText: 'Apakah batuk Anda berdahak?',
          promptText: 'batuk berdahak'),
      DiagnosisQuestion(
          questionText: 'Apakah dahak berwarna kuning atau hijau?',
          promptText: 'dahak berwarna kuning atau hijau'),
      DiagnosisQuestion(
          questionText: 'Apakah batuk terjadi terutama malam hari?',
          promptText: 'batuk terjadi terutama malam hari'),
      DiagnosisQuestion(
          questionText: 'Apakah batuk disertai nyeri dada?',
          promptText: 'batuk disertai nyeri dada'),
      DiagnosisQuestion(
          questionText: 'Apakah batuk menyebabkan sesak nafas?',
          promptText: 'batuk menyebabkan sesak nafas'),
      DiagnosisQuestion(
          questionText: 'Apakah Anda mengalami suara serak?',
          promptText: 'mengalami suara serak'),
      DiagnosisQuestion(
          questionText: 'Apakah batuk terjadi setelah aktivitas fisik?',
          promptText: 'batuk terjadi setelah aktivitas fisik'),
      DiagnosisQuestion(
          questionText: 'Apakah Anda batuk lebih dari 2 minggu?',
          promptText: 'batuk lebih dari 2 minggu'),
      DiagnosisQuestion(
          questionText: 'Apakah batuk disertai darah?',
          promptText: 'batuk disertai darah'),
      DiagnosisQuestion(
          questionText: 'Apakah Anda memiliki riwayat alergi?',
          promptText: 'memiliki riwayat alergi'),
    ],
    'Sesak Nafas': [
      DiagnosisQuestion(
          questionText: 'Apakah sesak terjadi saat beraktivitas ringan?',
          promptText: 'sesak terjadi saat beraktivitas ringan'),
      DiagnosisQuestion(
          questionText: 'Apakah Anda merasa dada terasa berat saat bernafas?',
          promptText: 'dada terasa berat saat bernafas'),
      DiagnosisQuestion(
          questionText: 'Apakah sesak terjadi mendadak?',
          promptText: 'sesak terjadi mendadak'),
      DiagnosisQuestion(
          questionText: 'Apakah sesak disertai suara "ngik-ngik" (wheezing)?',
          promptText: 'sesak disertai suara "ngik-ngik"'),
      DiagnosisQuestion(
          questionText: 'Apakah sesak memburuk saat berbaring?',
          promptText: 'sesak memburuk saat berbaring'),
      DiagnosisQuestion(
          questionText: 'Apakah Anda sering terbangun karena sulit bernafas?',
          promptText: 'sering terbangun karena sulit bernafas'),
      DiagnosisQuestion(
          questionText: 'Apakah sesak membaik setelah istirahat?',
          promptText: 'sesak membaik setelah istirahat'),
      DiagnosisQuestion(
          questionText: 'Apakah Anda memiliki riwayat asma atau PPOK?',
          promptText: 'memiliki riwayat asma atau PPOK'),
      DiagnosisQuestion(
          questionText: 'Apakah sesak disertai jantung berdebar?',
          promptText: 'sesak disertai jantung berdebar'),
      DiagnosisQuestion(
          questionText: 'Apakah ada pembengkakan di kaki atau pergelangan?',
          promptText: 'ada pembengkakan di kaki atau pergelangan'),
    ],
    'Nyeri Dada': [
      DiagnosisQuestion(
          questionText: 'Apakah nyeri seperti tertusuk atau tertekan berat?',
          promptText: 'nyeri seperti tertusuk atau tertekan berat'),
      DiagnosisQuestion(
          questionText: 'Apakah nyeri menjalar ke lengan kiri?',
          promptText: 'nyeri menjalar ke lengan kiri'),
      DiagnosisQuestion(
          questionText: 'Apakah nyeri muncul setelah aktivitas fisik?',
          promptText: 'nyeri muncul setelah aktivitas fisik'),
      DiagnosisQuestion(
          questionText: 'Apakah nyeri disertai sesak nafas?',
          promptText: 'nyeri disertai sesak nafas'),
      DiagnosisQuestion(
          questionText: 'Apakah nyeri berlangsung lebih dari 15 menit?',
          promptText: 'nyeri berlangsung lebih dari 15 menit'),
      DiagnosisQuestion(
          questionText: 'Apakah nyeri memburuk saat bernafas dalam?',
          promptText: 'nyeri memburuk saat bernafas dalam'),
      DiagnosisQuestion(
          questionText: 'Apakah Anda memiliki riwayat hipertensi atau jantung?',
          promptText: 'memiliki riwayat hipertensi atau jantung'),
      DiagnosisQuestion(
          questionText: 'Apakah nyeri dada muncul saat batuk?',
          promptText: 'nyeri dada muncul saat batuk'),
      DiagnosisQuestion(
          questionText: 'Apakah nyeri berkurang dengan istirahat?',
          promptText: 'nyeri berkurang dengan istirahat'),
      DiagnosisQuestion(
          questionText: 'Apakah nyeri disertai mual atau berkeringat dingin?',
          promptText: 'nyeri disertai mual atau berkeringat dingin'),
    ],
    'Sakit Kepala': [
      DiagnosisQuestion(
          questionText: 'Apakah sakit kepala terasa berdenyut?',
          promptText: 'sakit kepala terasa berdenyut'),
      DiagnosisQuestion(
          questionText: 'Apakah sakit kepala dirasakan di satu sisi kepala?',
          promptText: 'sakit kepala dirasakan di satu sisi'),
      DiagnosisQuestion(
          questionText: 'Apakah sakit kepala disertai mual/muntah?',
          promptText: 'sakit kepala disertai mual/muntah'),
      DiagnosisQuestion(
          questionText:
              'Apakah sakit kepala memburuk dengan cahaya atau suara?',
          promptText: 'sakit kepala memburuk dengan cahaya atau suara'),
      DiagnosisQuestion(
          questionText: 'Apakah sakit kepala muncul mendadak dan hebat?',
          promptText: 'sakit kepala muncul mendadak dan hebat'),
      DiagnosisQuestion(
          questionText:
              'Apakah Anda memiliki gangguan penglihatan saat sakit kepala muncul?',
          promptText: 'ada gangguan penglihatan saat sakit kepala'),
      DiagnosisQuestion(
          questionText: 'Apakah Anda kurang tidur sebelum sakit kepala muncul?',
          promptText: 'kurang tidur sebelum sakit kepala'),
      DiagnosisQuestion(
          questionText:
              'Apakah sakit kepala berkurang setelah minum obat pereda nyeri?',
          promptText: 'sakit kepala berkurang setelah minum obat'),
      DiagnosisQuestion(
          questionText: 'Apakah sakit kepala terjadi setiap hari?',
          promptText: 'sakit kepala terjadi setiap hari'),
      DiagnosisQuestion(
          questionText: 'Apakah sakit kepala disertai demam atau leher kaku?',
          promptText: 'sakit kepala disertai demam atau leher kaku'),
    ],
    'Ruam/Gatal': [
      DiagnosisQuestion(
          questionText: 'Apakah ruam terasa gatal atau perih?',
          promptText: 'ruam terasa gatal atau perih'),
      DiagnosisQuestion(
          questionText: 'Apakah ruam menyebar cepat ke seluruh tubuh?',
          promptText: 'ruam menyebar cepat ke seluruh tubuh'),
      DiagnosisQuestion(
          questionText:
              'Apakah ruam muncul setelah konsumsi makanan/obat tertentu?',
          promptText: 'ruam muncul setelah konsumsi makanan/obat'),
      DiagnosisQuestion(
          questionText: 'Apakah ruam disertai demam?',
          promptText: 'ruam disertai demam'),
      DiagnosisQuestion(
          questionText:
              'Apakah Anda mengalami pembengkakan di wajah atau bibir?',
          promptText: 'mengalami pembengkakan di wajah atau bibir'),
      DiagnosisQuestion(
          questionText: 'Apakah ruam disertai lepuhan?',
          promptText: 'ruam disertai lepuhan'),
      DiagnosisQuestion(
          questionText: 'Apakah ruam berwarna kemerahan atau keunguan?',
          promptText: 'ruam berwarna kemerahan atau keunguan'),
      DiagnosisQuestion(
          questionText: 'Apakah Anda pernah mengalami ruam serupa sebelumnya?',
          promptText: 'pernah mengalami ruam serupa sebelumnya'),
      DiagnosisQuestion(
          questionText: 'Apakah ruam memburuk setelah terpapar matahari?',
          promptText: 'ruam memburuk setelah terpapar matahari'),
      DiagnosisQuestion(
          questionText: 'Apakah ruam disertai nyeri sendi?',
          promptText: 'ruam disertai nyeri sendi'),
    ],
    'Sakit Perut': [
      DiagnosisQuestion(
          questionText:
              'Apakah sakit perut terlokalisasi di satu area tertentu?',
          promptText: 'sakit perut terlokalisasi di satu area tertentu'),
      DiagnosisQuestion(
          questionText: 'Apakah sakit perut disertai diare atau sembelit?',
          promptText: 'sakit perut disertai diare atau sembelit'),
      DiagnosisQuestion(
          questionText: 'Apakah sakit perut bertambah saat makan?',
          promptText: 'sakit perut bertambah saat makan'),
      DiagnosisQuestion(
          questionText: 'Apakah sakit perut menghilang setelah buang angin?',
          promptText: 'sakit perut menghilang setelah buang angin'),
      DiagnosisQuestion(
          questionText: 'Apakah sakit perut disertai mual/muntah?',
          promptText: 'mengalami pembengkakan di wajah atau bibir'),
      DiagnosisQuestion(
          questionText: 'Apakah sakit perut Anda terasa kembung?',
          promptText: 'sakit perut terasa kembung'),
      DiagnosisQuestion(
          questionText: 'Apakah sakit perut menetap lebih dari 24 jam?',
          promptText: 'sakit perut menetap lebih dari 24 jam'),
      DiagnosisQuestion(
          questionText: 'Apakah sakit perut disertai demam?',
          promptText: 'sakit perut disertai demam'),
      DiagnosisQuestion(
          questionText: 'Apakah Anda mengalami penurunan nafsu makan?',
          promptText: 'mengalami penurunan nafsu makan'),
      DiagnosisQuestion(
          questionText: 'Apakah ada darah di tinja?',
          promptText: 'mengalami ada darah di tinja'),
    ],
    'Mual/Muntah': [
      DiagnosisQuestion(
          questionText: 'Apakah mual muncul setelah makan?',
          promptText: 'mual muncul setelah makan'),
      DiagnosisQuestion(
          questionText: 'Apakah muntah disertai darah?',
          promptText: 'muntah disertai darah'),
      DiagnosisQuestion(
          questionText: 'Apakah Anda mengalami sakit kepala sebelum mual?',
          promptText: 'mengalami sakit kepala sebelum mual'),
      DiagnosisQuestion(
          questionText: 'Apakah Anda merasa pusing atau vertigo?',
          promptText: 'merasa pusing atau vertigo'),
      DiagnosisQuestion(
          questionText: 'Apakah mual disertai nyeri perut?',
          promptText: 'mual disertai nyeri perut'),
      DiagnosisQuestion(
          questionText: 'Apakah mual muncul pada pagi hari??',
          promptText: 'mual muncul pada pagi hari'),
      DiagnosisQuestion(
          questionText: 'Apakah Anda mengalami diare bersamaan?',
          promptText: 'mengalami diare bersamaan'),
      DiagnosisQuestion(
          questionText:
              'Apakah mual/muntah muncul setelah konsumsi obat tertentu?',
          promptText: 'mual/muntah muncul setelah konsumsi obat tertentu'),
      DiagnosisQuestion(
          questionText: 'Apakah Anda merasa demam bersamaan dengan mual?',
          promptText: 'merasa demam bersamaan dengan mual'),
      DiagnosisQuestion(
          questionText: 'Apakah Anda sedang atau mungkin hamil?',
          promptText: 'sedang atau mungkin hamil'),
    ],
    'Masalah BAK': [
      DiagnosisQuestion(
          questionText: 'Apakah Anda sering buang air kecil?',
          promptText: 'sering buang air kecil'),
      DiagnosisQuestion(
          questionText:
              'Apakah terasa nyeri atau terbakar saat buang air kecil?',
          promptText: 'terasa nyeri atau terbakar saat buang air kecil'),
      DiagnosisQuestion(
          questionText: 'Apakah urin Anda berwarna keruh atau berdarah?',
          promptText: 'urin berwarna keruh atau berdarah'),
      DiagnosisQuestion(
          questionText: 'Apakah Anda sulit menahan kencing?',
          promptText: 'sulit menahan kencing'),
      DiagnosisQuestion(
          questionText:
              'Apakah Anda merasa tidak tuntas setelah buang air kecil?',
          promptText: 'merasa tidak tuntas setelah buang air kecil'),
      DiagnosisQuestion(
          questionText: 'Apakah Anda bangun malam untuk buang air kecil?',
          promptText: 'mengalami bangun malam untuk buang air kecil'),
      DiagnosisQuestion(
          questionText: 'Apakah Anda mengalami demam bersamaan?',
          promptText: 'mengalami demam bersamaan'),
      DiagnosisQuestion(
          questionText: 'Apakah ada nyeri di pinggang atau perut bagian bawah?',
          promptText: 'ada nyeri di pinggang atau perut bagian bawah'),
      DiagnosisQuestion(
          questionText: 'Apakah Anda mengalami inkontinensia urin (beser)?',
          promptText: 'mengalami inkontinensia urin (beser)'),
      DiagnosisQuestion(
          questionText: 'Apakah Anda mengalami pembengkakan di perut bawah?',
          promptText: 'mengalami pembengkakan di perut bawah'),
    ],
    'Nyeri Sendi/Otot': [
      DiagnosisQuestion(
          questionText: 'Apakah nyeri dirasakan di lebih dari satu sendi?',
          promptText: 'nyeri dirasakan di lebih dari satu sendi'),
      DiagnosisQuestion(
          questionText: 'Apakah nyeri disertai bengkak di sendi?',
          promptText: 'nyeri disertai bengkak di sendi'),
      DiagnosisQuestion(
          questionText: 'Apakah nyeri terasa kaku di pagi hari?',
          promptText: 'nyeri terasa kaku di pagi hari'),
      DiagnosisQuestion(
          questionText: 'Apakah nyeri membaik setelah bergerak?',
          promptText: 'nyeri membaik setelah bergerak'),
      DiagnosisQuestion(
          questionText: 'Apakah nyeri disertai demam?',
          promptText: 'nyeri disertai demam'),
      DiagnosisQuestion(
          questionText: 'Apakah nyeri muncul setelah aktivitas berat?',
          promptText: 'mnyeri muncul setelah aktivitas berat'),
      DiagnosisQuestion(
          questionText: 'Apakah Anda memiliki riwayat rematik atau asam urat?',
          promptText: 'memiliki riwayat rematik atau asam urat'),
      DiagnosisQuestion(
          questionText: 'Apakah nyeri otot disertai kelemahan?',
          promptText: 'nyeri otot disertai kelemahan'),
      DiagnosisQuestion(
          questionText: 'Apakah nyeri menetap lebih dari 1 minggu?',
          promptText: 'nyeri menetap lebih dari 1 minggu'),
      DiagnosisQuestion(
          questionText: 'Apakah nyeri muncul setelah infeksi sebelumnya?',
          promptText: 'nyeri muncul setelah infeksi sebelumnya'),
    ]
    // Add other main symptoms and their questions here
  };

  final Set<String> _selectedSymptoms = {};
  bool _isLoading = false;
  Future<void> _startDiagnosis() async {
    if (_selectedSymptoms.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Pilih minimal satu gejala.')),
      );
      return;
    }

    setState(() {
      _isLoading = true;
    });

    try {
      // 1. Fetch User Data from Firestore
      final uid = FirebaseAuth.instance.currentUser?.uid;
      DocumentSnapshot? userDoc;
      if (uid != null) {
        userDoc =
            await FirebaseFirestore.instance.collection('users').doc(uid).get();
      }

      // 2. Construct the detailed initial prompt
      String userProfilePrompt = 'Konteks Pengguna: ';
      if (userDoc != null && userDoc.exists) {
        final data = userDoc.data() as Map<String, dynamic>;
        userProfilePrompt += 'Nama: ${data['fullName'] ?? 'N/A'}, ';
        userProfilePrompt += 'Usia: ${data['age'] ?? 'N/A'} tahun, ';
        userProfilePrompt += 'Jenis Kelamin: ${data['gender'] ?? 'N/A'}. ';
        final medicalHistory = List<String>.from(data['medicalHistory'] ?? []);
        if (medicalHistory.isNotEmpty) {
          userProfilePrompt +=
              'Memiliki riwayat medis: ${medicalHistory.join(', ')}. ';
        }
        final faktorKeluarga = data['faktorkeluarga'] as String?;
        if (faktorKeluarga != null && faktorKeluarga.isNotEmpty) {
          userProfilePrompt +=
              'Faktor genetik/penyakit turunan keluarga: $faktorKeluarga. ';
        }
      } else {
        userProfilePrompt = 'Konteks pengguna tidak tersedia. ';
      }

      final symptomsPrompt =
          'Pengguna memilih gejala utama: ${_selectedSymptoms.join(', ')}. ';
      final initialPrompt =
          userProfilePrompt + symptomsPrompt + 'Detail gejala yang dialami: ';

      // 3. Prepare the question flow
      final List<DiagnosisQuestion> questionsForFlow = [];
      _selectedSymptoms.forEach((symptom) {
        if (_symptomQuestions.containsKey(symptom)) {
          questionsForFlow.addAll(_symptomQuestions[symptom]!);
        }
      });
      final uniqueQuestions = questionsForFlow.toSet().toList();

      // 4. Navigate to the next page
      if (!mounted) return; // Check if the widget is still in the tree

      if (_selectedSymptoms.contains('Ruam/Gatal')) {
        Navigator.of(context).push(MaterialPageRoute(
          builder: (context) => RuamPhotoPage(
            initialPrompt: initialPrompt,
            questions: uniqueQuestions,
          ),
        ));
      } else {
        Navigator.of(context).push(MaterialPageRoute(
          builder: (context) => QuestionPage(
            questions: uniqueQuestions,
            currentQuestionIndex: 0,
            currentPrompt: initialPrompt,
          ),
        ));
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Gagal memuat data pengguna: ${e.toString()}')),
      );
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Diagnosis Pasien'),
        backgroundColor: Colors.orangeAccent,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            const Text(
              'Pilih gejala mana saja yang dirasakan',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 20),
            Expanded(
              child: GridView.builder(
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  crossAxisSpacing: 16,
                  mainAxisSpacing: 24,
                  childAspectRatio: 3,
                ),
                itemCount: _symptomQuestions.keys.length,
                itemBuilder: (context, index) {
                  final symptom = _symptomQuestions.keys.elementAt(index);
                  final isSelected = _selectedSymptoms.contains(symptom);

                  return FilterChip(
                    materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                    label: Row(children: [
                      SizedBox(
                        width: 3,
                        height: 40,
                      ),
                      Text(symptom,
                          style: const TextStyle(
                            fontSize: 16,
                            color: Colors.black,
                            fontWeight: FontWeight.w600,
                          ),
                          textAlign: TextAlign.right)
                    ]),
                    selected: isSelected,
                    onSelected: (bool selected) {
                      setState(() {
                        if (selected) {
                          _selectedSymptoms.add(symptom);
                        } else {
                          _selectedSymptoms.remove(symptom);
                        }
                      });
                    },
                    backgroundColor: Colors.orange.shade200,
                    selectedColor: Colors.orange.shade400,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(30),
                      side: BorderSide.none,
                    ),
                  );
                },
              ),
            ),
            _isLoading
                ? const CircularProgressIndicator()
                : ElevatedButton(
                    onPressed: _startDiagnosis,
                    child: const Text('Lanjutkan ke Pertanyaan'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.green,
                      foregroundColor: Colors.white,
                      minimumSize: const Size(double.infinity, 50),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(30),
                      ),
                    ),
                  )
          ],
        ),
      ),
    );
  }
}

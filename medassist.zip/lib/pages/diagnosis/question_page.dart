import 'package:flutter/material.dart';
import 'package:medassist/models/diagnosis_question.dart';
import 'package:medassist/pages/diagnosis/final_details_page.dart';

// Changed to a StatefulWidget to handle the text controller
class QuestionPage extends StatefulWidget {
  final List<DiagnosisQuestion> questions;
  final int currentQuestionIndex;
  final String currentPrompt;

  const QuestionPage({
    super.key,
    required this.questions,
    required this.currentQuestionIndex,
    required this.currentPrompt,
  });

  @override
  _QuestionPageState createState() => _QuestionPageState();
}

class _QuestionPageState extends State<QuestionPage> {
  final _textController = TextEditingController();

  @override
  void dispose() {
    _textController.dispose();
    super.dispose();
  }

  void _navigateToNextQuestion(String nextPrompt, int nextIndex) {
    if (nextIndex < widget.questions.length) {
      Navigator.of(context).pushReplacement(MaterialPageRoute(
        builder: (context) => QuestionPage(
          questions: widget.questions,
          currentQuestionIndex: nextIndex,
          currentPrompt: nextPrompt,
        ),
      ));
    } else {
      Navigator.of(context).pushReplacement(MaterialPageRoute(
        builder: (context) => FinalDetailsPage(prompt: nextPrompt),
      ));
    }
  }

  // Handles answers from the 4-button grid
  void _answerMultipleChoice(String answer) {
    final question = widget.questions[widget.currentQuestionIndex];
    String nextPrompt = widget.currentPrompt;
    int nextQuestionIndex = widget.currentQuestionIndex + 1;

    // Special logic for the thermometer question
    if (question.questionId == 'has_thermometer') {
      if (answer == 'Ya') {
        // Just proceed to the next question (temperature input)
      } else {
        // For "Tidak", "Mungkin", or "Tidak Tahu", add the prompt and skip the temperature question
        nextPrompt = '$nextPrompt${question.promptText}, ';
        nextQuestionIndex = widget.currentQuestionIndex + 2;
      }
    } else {
      // Standard logic for all other multiple-choice questions
      if (answer == 'Ya') {
        nextPrompt =
            '$nextPrompt${"Pasien merasakan " + question.promptText}, ';
      } else if (answer == "Tidak") {
        nextPrompt =
            '$nextPrompt${"Pasien tidak merasakan " + question.promptText}, ';
      } else if (answer == "Mungkin") {
        nextPrompt =
            '$nextPrompt${"Pasien mungkin merasakan " + question.promptText}, ';
      } else if (answer == "Tidak Tahu") {
        nextPrompt =
            '$nextPrompt${"Pasien tidak tahu apakah merasakan " + question.promptText}, ';
      }
    }
    _navigateToNextQuestion(nextPrompt, nextQuestionIndex);
  }

  // Handles submission from the text input field
  void _answerWithText() {
    final question = widget.questions[widget.currentQuestionIndex];
    final userInput = _textController.text;
    if (userInput.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Mohon masukkan suhu tubuh Anda.')),
      );
      return;
    }

    // Construct the prompt, e.g., "suhu tubuh 39�C"
    final nextPrompt =
        '${widget.currentPrompt}${question.promptText} $userInput�C, ';
    _navigateToNextQuestion(nextPrompt, widget.currentQuestionIndex + 1);
  }

  @override
  Widget build(BuildContext context) {
    if (widget.questions.isEmpty ||
        widget.currentQuestionIndex >= widget.questions.length) {
      return const Scaffold(
          body: Center(child: Text("Kuesioner tidak valid.")));
    }

    final question = widget.questions[widget.currentQuestionIndex];

    // Conditionally build the UI based on the question type
    if (question.isTextInput) {
      return _buildTextInputPage(context, question);
    } else {
      return _buildMultipleChoicePage(context, question);
    }
  }

  // UI for Text Input Questions
  Widget _buildTextInputPage(BuildContext context, DiagnosisQuestion question) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
            'Pertanyaan ${widget.currentQuestionIndex + 1} dari ${widget.questions.length}'),
        backgroundColor: Colors.orangeAccent,
      ),
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(
              question.questionText,
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 20),
            TextField(
              controller: _textController,
              keyboardType:
                  const TextInputType.numberWithOptions(decimal: true),
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 20),
              decoration: InputDecoration(
                hintText: 'Contoh: 38.5',
                border:
                    OutlineInputBorder(borderRadius: BorderRadius.circular(20)),
              ),
            ),
            const SizedBox(height: 30),
            ElevatedButton(
              onPressed: _answerWithText,
              child: const Text('Lanjut'),
              style: ElevatedButton.styleFrom(
                padding: const EdgeInsets.symmetric(vertical: 15),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(20)),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // UI for Multiple Choice Questions
  Widget _buildMultipleChoicePage(
      BuildContext context, DiagnosisQuestion question) {
    const answers = ['Ya', 'Tidak', 'Mungkin', 'Tidak Tahu'];
    return Scaffold(
      appBar: AppBar(
        title: Text(
            'Pertanyaan ${widget.currentQuestionIndex + 1} dari ${widget.questions.length}'),
        backgroundColor: Colors.orangeAccent,
      ),
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                question.questionText,
                textAlign: TextAlign.center,
                style:
                    const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 40),
              GridView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  crossAxisSpacing: 16,
                  mainAxisSpacing: 16,
                  childAspectRatio: 2.2,
                ),
                itemCount: answers.length,
                itemBuilder: (context, index) {
                  final answer = answers[index];
                  return ElevatedButton(
                    onPressed: () => _answerMultipleChoice(answer),
                    child: Text(answer,
                        style: const TextStyle(fontWeight: FontWeight.bold)),
                    style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.orange.shade200,
                        foregroundColor: Colors.black,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(20),
                        )),
                  );
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}

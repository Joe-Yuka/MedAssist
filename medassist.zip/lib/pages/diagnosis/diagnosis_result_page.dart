import 'package:flutter/material.dart';
import 'package:medassist/pages/diagnosis/disease_detail_page.dart';

class DiagnosisResultPage extends StatelessWidget {
  final List<Map<String, dynamic>> results;

  const DiagnosisResultPage({super.key, required this.results});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Kemungkinan Diagnosis'),
        backgroundColor: Colors.orangeAccent,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Text(
              'Presentase penyakit yang mungkin anda derita:',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 18, color: Colors.grey.shade700),
            ),
            const SizedBox(height: 20),
            Expanded(
              child: ListView.builder(
                itemCount: results.length,
                itemBuilder: (context, index) {
                  final result = results[index];
                  // Use a StatefulWidget for the animated bar
                  return DiagnosisResultBar(result: result);
                },
              ),
            )
          ],
        ),
      ),
    );
  }
}

// --- NEW WIDGET FOR THE ANIMATED BAR ---
class DiagnosisResultBar extends StatefulWidget {
  final Map<String, dynamic> result;

  const DiagnosisResultBar({super.key, required this.result});

  @override
  _DiagnosisResultBarState createState() => _DiagnosisResultBarState();
}

class _DiagnosisResultBarState extends State<DiagnosisResultBar> {
  bool _isAnimated = false;

  @override
  void initState() {
    super.initState();
    // Trigger the animation shortly after the widget is built
    WidgetsBinding.instance.addPostFrameCallback((_) {
      setState(() {
        _isAnimated = true;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    final int percentage = widget.result['percentage'] as int;
    final String diseaseName = widget.result['disease'] as String;

    return Card(
      margin: const EdgeInsets.symmetric(vertical: 8.0),
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
      clipBehavior:
          Clip.antiAlias, // Ensures the content respects the border radius
      child: InkWell(
        onTap: () {
          Navigator.of(context).push(MaterialPageRoute(
            builder: (context) => DiseaseDetailPage(diseaseName: diseaseName),
          ));
        },
        child: SizedBox(
          height: 70,
          child: Stack(
            alignment: Alignment.centerLeft,
            children: [
              // The animated background bar
              AnimatedContainer(
                duration: const Duration(milliseconds: 800),
                curve: Curves.easeInOut,
                width: _isAnimated
                    ? (MediaQuery.of(context).size.width - 32) *
                        (percentage / 100)
                    : 0,
                height: 70,
                decoration: BoxDecoration(
                  color: Colors.yellow.shade600.withOpacity(0.8),
                ),
              ),
              // The content on top of the bar
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(
                      child: Text(
                        diseaseName,
                        style: const TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                            color: Colors.black87),
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    const SizedBox(width: 15),
                    Text(
                      '$percentage%',
                      style: const TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                          color: Colors.black),
                    ),
                    const SizedBox(width: 10),
                    const Icon(Icons.arrow_forward_ios, color: Colors.grey),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

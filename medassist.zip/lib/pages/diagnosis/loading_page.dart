import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:firebase_auth/firebase_auth.dart';
import 'package:medassist/pages/diagnosis/diagnosis_result_page.dart';
import 'package:medassist/services/firestore_service.dart';

class LoadingPage extends StatefulWidget {
  final String prompt;
  const LoadingPage({super.key, required this.prompt});

  @override
  _LoadingPageState createState() => _LoadingPageState();
}

class _LoadingPageState extends State<LoadingPage> {
  @override
  void initState() {
    super.initState();
    _getDiagnosis();
  }

  Future<void> _getDiagnosis() async {
    const String n8nWebhookUrl =
        'https://medassist1.app.n8n.cloud/webhook/aaf8142f-6169-4d40-a41c-f9f8516b2ebf';

    try {
      final response = await http.post(
        Uri.parse(n8nWebhookUrl),
        headers: {'Content-Type': 'application/json'},
        body: json.encode({'chatInput': widget.prompt}),
      );

      if (response.statusCode == 200) {
        final jsonResponse = json.decode(utf8.decode(response.bodyBytes));
        final n8nOutput = jsonResponse[0]['output'];

        Map<String, dynamic>? agentOutput;

        if (n8nOutput is String) {
          agentOutput = json.decode(n8nOutput);
        } else if (n8nOutput is Map<String, dynamic>) {
          agentOutput = n8nOutput;
        }

        if (agentOutput == null || agentOutput['results'] == null) {
          throw Exception(
              "Failed to parse the diagnosis results from the AI's response.");
        }

        List<Map<String, dynamic>> results =
            List<Map<String, dynamic>>.from(agentOutput['results']);
        results.sort((a, b) =>
            (b['percentage'] as int).compareTo(a['percentage'] as int));

        // --- UPDATED CALL ---
        // Now we pass the prompt along with the results to be saved.
        try {
          final uid = FirebaseAuth.instance.currentUser?.uid;
          if (uid != null) {
            await FirestoreService()
                .saveDiagnosisHistory(uid, results, widget.prompt);
          }
        } catch (e) {
          print("Failed to save history: $e");
        }

        if (mounted) {
          Navigator.of(context).pushReplacement(MaterialPageRoute(
            builder: (context) => DiagnosisResultPage(results: results),
          ));
        }
      } else {
        throw Exception(
            'Failed to get diagnosis. Status code: ${response.statusCode}, Body: ${response.body}');
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
              content: Text('An error occurred: ${e.toString()}'),
              backgroundColor: Colors.red),
        );
        Navigator.of(context).pop();
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.orangeAccent,
        automaticallyImplyLeading: false,
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Text(
                'MEMPROSES DATA',
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
              ),
              const Text(
                'Tunggu beberapa menit',
                style: TextStyle(fontSize: 16, color: Colors.grey),
              ),
              const SizedBox(height: 40),
              const CircularProgressIndicator(
                strokeWidth: 6,
                valueColor: AlwaysStoppedAnimation<Color>(Colors.grey),
              ),
              const Spacer(),
              Container(
                height: 60,
                width: 500,
                decoration: const BoxDecoration(
                    image: DecorationImage(
                        image: AssetImage(
                  'assets/images/powered-by-azure.png',
                ))),
              ),
              const SizedBox(height: 10),
              const Text(
                  'MedAssist dapat membuat kesalahan. Periksa info penting',
                  style: TextStyle(fontSize: 13, color: Colors.grey)),
            ],
          ),
        ),
      ),
    );
  }
}

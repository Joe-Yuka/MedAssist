import 'package:flutter/material.dart';
import 'package:medassist/pages/diagnosis/loading_page.dart';

class FinalDetailsPage extends StatefulWidget {
  final String prompt;
  const FinalDetailsPage({super.key, required this.prompt});

  @override
  _FinalDetailsPageState createState() => _FinalDetailsPageState();
}

class _FinalDetailsPageState extends State<FinalDetailsPage> {
  final _detailsController = TextEditingController();
  final _obatController = TextEditingController();

  void _submitForDiagnosis() {
    final finalPrompt =
        '${widget.prompt}. \nObat yang sudah dipakai sebelumnya: ${_obatController.text.isNotEmpty ? _obatController.text : 'Tidak ada.'}\nInfo tambahan: ${_detailsController.text.isNotEmpty ? _detailsController.text : 'Tidak ada.'}';

    // For debugging, you can print the final prompt
    print("--- FINAL PROMPT ---");
    print(finalPrompt);
    print("--------------------");

    Navigator.of(context).pushReplacement(MaterialPageRoute(
      builder: (context) => LoadingPage(prompt: finalPrompt),
    ));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Detail Tambahan'),
        backgroundColor: Colors.orangeAccent,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Text(
              'Sebutkan obat apa saja yang sudah dipakai sebelumnya',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 20),
            Expanded(
              child: TextField(
                controller: _obatController,
                maxLines: null,
                expands: true,
                textAlignVertical: TextAlignVertical.top,
                decoration: InputDecoration(
                  hintText: '...',
                  filled: true,
                  fillColor: Colors.grey.shade200,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(15),
                    borderSide: BorderSide.none,
                  ),
                ),
              ),
            ),
            const SizedBox(height: 20),
            const Text(
              'Tolong deskripsikan gejala lain yang mungkin anda rasakan',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 20),
            Expanded(
              child: TextField(
                controller: _detailsController,
                maxLines: null,
                expands: true,
                textAlignVertical: TextAlignVertical.top,
                decoration: InputDecoration(
                  hintText: '...',
                  filled: true,
                  fillColor: Colors.grey.shade200,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(15),
                    borderSide: BorderSide.none,
                  ),
                ),
              ),
            ),
            const SizedBox(height: 20),
            Row(
              children: [
                Expanded(
                  child: ElevatedButton(
                    onPressed: _submitForDiagnosis, // Also submits
                    child: const Text('Tidak Tahu'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.grey.shade800,
                      foregroundColor: Colors.white,
                      minimumSize: const Size(0, 50),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(20)),
                    ),
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: ElevatedButton(
                    onPressed: _submitForDiagnosis,
                    child: const Text('Submit'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.orange.shade300,
                      foregroundColor: Colors.black,
                      minimumSize: const Size(0, 50),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(20)),
                    ),
                  ),
                ),
              ],
            )
          ],
        ),
      ),
    );
  }
}

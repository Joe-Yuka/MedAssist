import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:intl/intl.dart';

class RiwayatDiagnosaPage extends StatelessWidget {
  const RiwayatDiagnosaPage({super.key});

  // Helper to format the prompt for better readability
  String _formatPrompt(String prompt) {
    // A simple way to make the prompt more readable
    return prompt
        .replaceAll('. Gejala yang dialami: ', '.\n\nGejala yang dialami:\n- ')
        .replaceAll(', ', '\n- ')
        .replaceAll('Info tambahan: ', '\n\nInfo tambahan:\n');
  }

  @override
  Widget build(BuildContext context) {
    final uid = FirebaseAuth.instance.currentUser?.uid;

    if (uid == null) {
      return Scaffold(
        appBar: AppBar(title: const Text("Riwayat Diagnosa")),
        body: const Center(
            child: Text("Pengguna tidak ditemukan. Mohon login kembali.")),
      );
    }

    final historyStream = FirebaseFirestore.instance
        .collection('users')
        .doc(uid)
        .collection('diagnosis_history')
        .orderBy('timestamp', descending: true)
        .snapshots();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Riwayat Diagnosa'),
        backgroundColor: Colors.orangeAccent,
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: historyStream,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
            return const Center(child: Text('Belum ada riwayat diagnosis.'));
          }
          if (snapshot.hasError) {
            return const Center(child: Text('Gagal memuat riwayat.'));
          }

          final histories = snapshot.data!.docs;

          return ListView.builder(
            itemCount: histories.length,
            itemBuilder: (context, index) {
              final historyDoc = histories[index];
              final data = historyDoc.data() as Map<String, dynamic>;
              final timestamp = (data['timestamp'] as Timestamp?)?.toDate();
              final results =
                  List<Map<String, dynamic>>.from(data['results'] ?? []);
              final prompt = data['prompt'] as String? ??
                  'Detail jawaban tidak tersimpan.';

              final topResult = results.isNotEmpty
                  ? results[0]['disease']
                  : 'Tidak ada hasil';
              final dateString = timestamp != null
                  ? DateFormat('EEEE, d MMMM yyyy HH:mm', 'id_ID')
                      .format(timestamp)
                  : 'Tanggal tidak diketahui';

              return Card(
                margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12)),
                elevation: 3,
                child: ExpansionTile(
                  leading: const Icon(Icons.history_edu,
                      color: Colors.orangeAccent, size: 30),
                  title: Text("Diagnosis: $topResult",
                      style: const TextStyle(fontWeight: FontWeight.bold)),
                  subtitle: Text(dateString),
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(16.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            "Detail Jawaban Pengguna:",
                            style: TextStyle(
                                fontWeight: FontWeight.bold, fontSize: 16),
                          ),
                          const SizedBox(height: 8),
                          Container(
                            padding: const EdgeInsets.all(12),
                            decoration: BoxDecoration(
                              color: Colors.grey.shade100,
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: Text(
                              _formatPrompt(prompt),
                              style: const TextStyle(height: 1.5),
                            ),
                          ),
                          const SizedBox(height: 12),
                          const Text(
                            "Hasil Analisis:",
                            style: TextStyle(
                                fontWeight: FontWeight.bold, fontSize: 16),
                          ),
                          const SizedBox(height: 8),
                          // Displaying all results
                          ...results
                              .map((result) => ListTile(
                                    dense: true,
                                    title: Text(result['disease']),
                                    trailing: Text('${result['percentage']}%',
                                        style: const TextStyle(
                                            fontWeight: FontWeight.bold)),
                                  ))
                              .toList(),
                          const SizedBox(height: 12),
                          ElevatedButton(
                            child: Text(
                              'Recall',
                              style: const TextStyle(fontSize: 16),
                            ),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.blue.shade600,
                              foregroundColor: Colors.white,
                              padding: const EdgeInsets.symmetric(
                                  vertical: 15, horizontal: 100),
                              shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(30)),
                            ),
                            onPressed: () {},
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              );
            },
          );
        },
      ),
    );
  }
}

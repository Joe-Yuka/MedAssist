import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:intl/intl.dart';
import 'package:medassist/pages/data_kesehatan/rekam_medis_page.dart';
import 'package:medassist/pages/home/home_page.dart';
import 'package:medassist/services/firestore_service.dart';

class DataKesehatanPage extends StatefulWidget {
  // We add a flag to determine if this is the initial setup or an edit.
  final bool isFirstTime;

  const DataKesehatanPage(
      {super.key,
      this.isFirstTime =
          true // Default to true for the initial flow after login
      });

  @override
  _DataKesehatanPageState createState() => _DataKesehatanPageState();
}

class _DataKesehatanPageState extends State<DataKesehatanPage> {
  final _formKey = GlobalKey<FormState>();
  final _firestoreService = FirestoreService();
  final _auth = FirebaseAuth.instance;

  // Controllers
  final _namaController = TextEditingController();
  final _tglLahirController = TextEditingController();
  final _ktpController = TextEditingController();
  final _alamatController = TextEditingController();
  final _usiaController = TextEditingController();
  final _teleponController = TextEditingController();
  final _pekerjaanController = TextEditingController();
  final _faktorKeluarga = TextEditingController();

  // Variables
  String? _jenisKelamin;
  String? _status;
  DateTime? _selectedDate;
  List<String> _rekamMedis = [];
  bool _isLoading = false;

  @override
  void initState() {
    super.initState();
    // If the user is editing their data (not the first time), fetch it.
    if (!widget.isFirstTime) {
      _fetchAndSetUserData();
    }
  }

  // --- NEW METHOD TO FETCH AND FILL DATA ---
  Future<void> _fetchAndSetUserData() async {
    setState(() => _isLoading = true);
    final uid = _auth.currentUser?.uid;
    if (uid == null) return;

    try {
      final userDoc =
          await FirebaseFirestore.instance.collection('users').doc(uid).get();
      if (userDoc.exists) {
        final data = userDoc.data()!;
        _namaController.text = data['fullName'] ?? '';
        _tglLahirController.text = data['dateOfBirth'] ?? '';
        _ktpController.text = data['ktp'] ?? '';
        _alamatController.text = data['address'] ?? '';
        _usiaController.text = (data['age'] ?? 0).toString();
        _teleponController.text = data['phone'] ?? '';
        _pekerjaanController.text = data['occupation'] ?? '';
        _faktorKeluarga.text = data['faktorkeluarga'] ?? '';

        setState(() {
          _jenisKelamin = data['gender'];
          _status = data['maritalStatus'];
          // Convert List<dynamic> to List<String>
          _rekamMedis = List<String>.from(data['medicalHistory'] ?? []);
        });
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Gagal memuat data: ${e.toString()}')));
    } finally {
      setState(() => _isLoading = false);
    }
  }

  @override
  void dispose() {
    _namaController.dispose();
    _tglLahirController.dispose();
    _ktpController.dispose();
    _alamatController.dispose();
    _usiaController.dispose();
    _teleponController.dispose();
    _pekerjaanController.dispose();
    _faktorKeluarga.dispose();
    super.dispose();
  }

  Future<void> _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: _selectedDate ?? DateTime.now(),
      firstDate: DateTime(1900),
      lastDate: DateTime.now(),
    );
    if (picked != null && picked != _selectedDate) {
      setState(() {
        _selectedDate = picked;
        _tglLahirController.text = DateFormat('d MMMM yyyy').format(picked);
      });
    }
  }

  void _submitData() async {
    if (_formKey.currentState!.validate()) {
      if (_jenisKelamin == null || _status == null) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Please fill all fields')),
        );
        return;
      }

      setState(() => _isLoading = true);

      try {
        final uid = _auth.currentUser!.uid;
        Map<String, dynamic> medicalData = {
          'fullName': _namaController.text,
          'dateOfBirth': _tglLahirController.text,
          'gender': _jenisKelamin,
          'address': _alamatController.text,
          'age': int.tryParse(_usiaController.text) ?? 0,
          'phone': _teleponController.text,
          'occupation': _pekerjaanController.text,
          'maritalStatus': _status,
          'medicalHistory': _rekamMedis,
          'faktorkeluarga': _faktorKeluarga.text,
        };

        await _firestoreService.updateMedicalData(uid, medicalData);

        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Data berhasil disimpan!')),
          );

          if (widget.isFirstTime) {
            // If it's the first time, navigate to home and clear the stack.
            Navigator.of(context).pushAndRemoveUntil(
              MaterialPageRoute(builder: (context) => const HomePage()),
              (Route<dynamic> route) => false,
            );
          } else {
            // If they were just editing, simply pop back.
            Navigator.of(context).pop();
          }
        }
      } catch (e) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed to save data: ${e.toString()}')),
        );
      } finally {
        if (mounted) {
          setState(() => _isLoading = false);
        }
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('MedAssist'),
        backgroundColor: Colors.orangeAccent,
        // --- CONDITIONAL BACK BUTTON LOGIC ---
        // `automaticallyImplyLeading` controls the back button.
        // If it's the first time, it's false (no back button).
        // If not the first time, it's true (show back button).
        automaticallyImplyLeading: !widget.isFirstTime,
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : Form(
              key: _formKey,
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(20.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    const Center(
                      child: Text('Data Pasien',
                          style: TextStyle(
                              fontSize: 24, fontWeight: FontWeight.bold)),
                    ),
                    const SizedBox(height: 20),
                    _buildTextFormField(
                        label: 'Nama Lengkap',
                        controller: _namaController,
                        hint: 'Raditya Qurrota'),
                    _buildTextFormField(
                      label: 'Tanggal Lahir',
                      controller: _tglLahirController,
                      hint: '19 Mei 2001',
                      readOnly: true,
                      onTap: () => _selectDate(context),
                    ),
                    _buildDropdown(
                      label: 'Jenis Kelamin',
                      hint: 'Laki-Laki',
                      value: _jenisKelamin,
                      items: ['Laki-Laki', 'Perempuan', 'Prefer not to say'],
                      onChanged: (value) =>
                          setState(() => _jenisKelamin = value),
                    ),
                    _buildTextFormField(
                        label: 'Alamat',
                        controller: _alamatController,
                        hint: 'Jln. Merdeka Raya Y21F23, Kota Malang'),
                    _buildTextFormField(
                        label: 'Usia',
                        controller: _usiaController,
                        hint: '24 Tahun',
                        keyboardType: TextInputType.number),
                    _buildTextFormField(
                        label: 'No. Telepon',
                        controller: _teleponController,
                        hint: '081234567890',
                        keyboardType: TextInputType.phone),
                    _buildTextFormField(
                        label: 'Pekerjaan',
                        controller: _pekerjaanController,
                        hint: 'Swasta'),
                    _buildDropdown(
                      label: 'Status',
                      hint: 'Menikah',
                      value: _status,
                      items: ['Menikah', 'Lajang'],
                      onChanged: (value) => setState(() => _status = value),
                    ),
                    _buildTextFormField(
                        label: 'Faktor Genetik / Penyakit Turunan',
                        controller: _faktorKeluarga,
                        hint: 'Asma'),
                    _buildRekamMedisButton(),
                    const SizedBox(height: 30),
                    ElevatedButton(
                      onPressed: _submitData,
                      child: const Text('Submit'),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.green,
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(vertical: 16),
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(30)),
                      ),
                    ),
                  ],
                ),
              ),
            ),
    );
  }

  Widget _buildTextFormField(
      {required String label,
      required TextEditingController controller,
      required String hint,
      bool readOnly = false,
      VoidCallback? onTap,
      TextInputType? keyboardType,
      int? maxLength}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: const TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 5),
          TextFormField(
            controller: controller,
            readOnly: readOnly,
            onTap: onTap,
            keyboardType: keyboardType,
            maxLength: maxLength,
            decoration: InputDecoration(
              hintText: hint,
              filled: true,
              fillColor: Colors.white,
              border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(30),
                  borderSide: const BorderSide(color: Colors.grey)),
              contentPadding:
                  const EdgeInsets.symmetric(horizontal: 20, vertical: 15),
              counterText: "",
            ),
            validator: (value) {
              if (value == null || value.isEmpty) {
                return 'This field cannot be empty';
              }
              return null;
            },
          ),
        ],
      ),
    );
  }

  Widget _buildDropdown(
      {required String label,
      required String hint,
      String? value,
      required List<String> items,
      required ValueChanged<String?> onChanged}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: const TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 5),
          DropdownButtonFormField<String>(
            value: value,
            items: items.map((String item) {
              return DropdownMenuItem<String>(
                value: item,
                child: Text(item),
              );
            }).toList(),
            onChanged: onChanged,
            decoration: InputDecoration(
              hintText: hint,
              filled: true,
              fillColor: Colors.white,
              border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(30),
                  borderSide: const BorderSide(color: Colors.grey)),
              contentPadding:
                  const EdgeInsets.symmetric(horizontal: 20, vertical: 15),
            ),
            validator: (value) =>
                value == null ? 'Please select an option' : null,
          ),
        ],
      ),
    );
  }

  Widget _buildRekamMedisButton() {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Rekam Medis',
              style: TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 5),
          InkWell(
            onTap: () async {
              final result = await Navigator.push<List<String>>(
                context,
                MaterialPageRoute(builder: (context) => const RekamMedisPage()),
              );
              if (result != null) {
                setState(() {
                  _rekamMedis = result;
                });
              }
            },
            child: InputDecorator(
              decoration: InputDecoration(
                filled: true,
                fillColor: Colors.white,
                border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(30),
                    borderSide: const BorderSide(color: Colors.grey)),
                contentPadding:
                    const EdgeInsets.symmetric(horizontal: 20, vertical: 15),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Expanded(
                    child: Text(_rekamMedis.isEmpty
                        ? 'Pilih riwayat'
                        : _rekamMedis.join(', ')),
                  ),
                  const Icon(Icons.arrow_forward_ios),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

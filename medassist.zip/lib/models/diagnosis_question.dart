// lib/models/diagnosis_question.dart

class DiagnosisQuestion {
  final String questionId; // To identify special questions for logic
  final String questionText;
  final String promptText; // The text to add to the prompt
  final bool isTextInput; // Flag to determine UI type

  DiagnosisQuestion({
    this.questionId = '', // Default to empty
    required this.questionText,
    required this.promptText,
    this.isTextInput = false, // Default to false
  });

  // Override equality and hashCode to allow usage in Sets (for finding unique questions)
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is DiagnosisQuestion &&
          runtimeType == other.runtimeType &&
          questionText == other.questionText;

  @override
  int get hashCode => questionText.hashCode;
}

import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:intl/date_symbol_data_local.dart'; // Import this for initialization
import 'package:medassist/pages/auth/login_page.dart';
import 'package:medassist/pages/home/home_page.dart';
import 'package:medassist/services/firestore_service.dart';
import 'package:medassist/pages/data_kesehatan/data_kesehatan_page.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  // --- FIX IS HERE ---
  // Initialize date formatting for the 'id_ID' (Indonesian) locale.
  await initializeDateFormatting('id_ID', null);
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'MedAssist',
      theme: ThemeData(
        primarySwatch: Colors.orange,
        fontFamily: 'NotoSans',
      ),
      debugShowCheckedModeBanner: false,
      home: const AuthWrapper(),
    );
  }
}

class AuthWrapper extends StatelessWidget {
  const AuthWrapper({super.key});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<User?>(
      stream: FirebaseAuth.instance.authStateChanges(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Scaffold(
              body: Center(child: CircularProgressIndicator()));
        }
        if (snapshot.hasData) {
          // User is logged in, check if medical data is complete
          return FutureBuilder<bool>(
            future:
                FirestoreService().isMedicalDataComplete(snapshot.data!.uid),
            builder: (context, dataSnapshot) {
              if (dataSnapshot.connectionState == ConnectionState.waiting) {
                return const Scaffold(
                    body: Center(child: CircularProgressIndicator()));
              }
              if (dataSnapshot.data == true) {
                return const HomePage();
              } else {
                return const DataKesehatanPage();
              }
            },
          );
        }
        return const LoginPage();
      },
    );
  }
}

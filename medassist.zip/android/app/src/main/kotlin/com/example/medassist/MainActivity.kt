package com.example.medassist

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
